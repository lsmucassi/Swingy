public class Swingy {
    public static void main(String[] args) {


        if (args.length != 1) {
            System.out.println("Error: You need to pass one argument to the game");
        }

        Character gmode = args[0].toLowerCase().equals("cli") ? 'A' : (args[0].toLowerCase().equals("gui")  ? 'B' : 'C') ;
        try {
            switch(gmode) {
                case 'A' :
                    System.out.println("Game Mode: Terminal mode [cli]");
                    System.out.println("Welcome to Swingy - A world of the unknown");
                    //play.start("cli");
                    break ;
                case 'B' :
                    System.out.println("Game Mode: Terminal mode [gui]");
                    System.out.println("Welcome to Swingy - A world of the unknown");
                    //play.start("gui");
                    break ;
                default :
                    System.out.println("Error: argument name must either be cli or gui");
                    break ;
            }
        } catch (IndexOutOfBoundsException gm) {
            System.out.println("Error: incorrect argument description" + gm.getMessage());
            return ;
        }
    }
}
